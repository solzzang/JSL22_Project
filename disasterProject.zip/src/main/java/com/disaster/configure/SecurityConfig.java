package com.disaster.configure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/", "/member/login", "/member/signup", "/member/check-**", "/member/send-**", "/member/verify-**", "/css/**", "/js/**", "/images/**").permitAll()
             	.requestMatchers("/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/member/login")
                .loginProcessingUrl("/login")
                .usernameParameter("username")  // 이 줄 추가
                .passwordParameter("password")  // 이 줄 추가
                //.defaultSuccessUrl("/")
                .successHandler(successHandler())
                .failureUrl("/member/login?error=true")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/")
                .permitAll()
            )
            .csrf(csrf -> csrf.disable());

        return http.build();
    }
    
    
    
    
    @Bean
    public AuthenticationSuccessHandler successHandler() {
		//로그인 성공후 동작을 정의하는 스프링 세큐리티 인터페이스
		return (request,response,autentication) -> {
			boolean isAdmin = autentication.getAuthorities().stream()
					.anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN"));
			
			if(isAdmin) {
				response.sendRedirect("/admin/adminDetail");
			}else {
				response.sendRedirect("/");
			}
			
		};
    
	}
    
    
    
    
}
package com.disaster.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.disaster.domain.AdminLogDTO;
import com.disaster.domain.CommentDTO;
import com.disaster.domain.CommunityDTO;
import com.disaster.domain.MemberDTO;
import com.disaster.service.AdminLogService;
import com.disaster.service.CommunityService;
import com.disaster.service.MemberService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {
    
	private final MemberService memberService;
	private final CommunityService communityService;
	private final AdminLogService adminLogService;
	
    @GetMapping("/adminDetail")
    public String admin(Model model) {
    		//신규 회원 수
    		int newMember = memberService.getNewMemberCount();
    		model.addAttribute("count",newMember);
    		//전체 회원 수
    		int totalMember = memberService.getTotalMemberCount();
    		model.addAttribute("total",totalMember);
    		//전체 회원 정보
    		List<MemberDTO> memberList = memberService.getMemberList();
    		model.addAttribute("memberlist",memberList);
    		//게시글 수
    		int totalPost = communityService.getTotalPostCount();
    		model.addAttribute("post",totalPost);
    		//댓글 수
    		int totalComment = communityService.getTotalCommentCount();
    		model.addAttribute("comment",totalComment);
    		
    		//게시글 조회 (신고된 게시글 우선)
    		List<CommunityDTO> postList = communityService.findAllPostsWithReportedFirst();
    		model.addAttribute("postList", postList);
    		//신고된 댓글 조회 
    		List<CommentDTO> commentList = communityService.findReportedComments();
    		model.addAttribute("commentList", commentList);
    		
    		// ----------------- 추가될 로직 -----------------
            // 소프트 삭제된 게시물 목록
            List<CommunityDTO> deletedPosts = communityService.findSoftDeletedPosts();
            model.addAttribute("deletedPostList", deletedPosts);
            
            // 소프트 삭제된 댓글 목록
            List<CommentDTO> deletedComments = communityService.findSoftDeletedComments();
            model.addAttribute("deletedCommentList", deletedComments);
            // ---------------------------------------------
    		
            // 관리자 활동 로그 조회
            List<AdminLogDTO> logList = adminLogService.getLogs();
            model.addAttribute("logList", logList);
    		
    		
        return "admin/adminDetail"; // templates/admin/dashboard.html
    }
    
 // 회원 관리 (삭제) 
    @PostMapping("/deleteMember")
    public String deleteMember(@RequestParam("memberId") Long memberId) {
        memberService.deleteMember(memberId);

        return "redirect:/admin/adminDetail";
    }
    
    
    /**
     * 게시글을 소프트 삭제합니다.
     */
    @PostMapping("/delete-post")
    public String deletePost(@RequestParam("postId") Long postId) {
        // TODO 1: 현재 로그인한 관리자의 ID를 가져와야 합니다.
        //         Spring Security를 사용한다면 @AuthenticationPrincipal 어노테이션 등으로 얻을 수 있습니다.
        Long currentAdminId = 1L; // 임시로 관리자 ID를 1로 가정합니다.

        // TODO 2: 삭제 사유를 파라미터로 받거나 기본값을 지정합니다.
        String reason = "관리자에 의한 게시글 숨김 처리";

        // 올바른 메소드(softDeletePost)를 호출하고, 필요한 모든 파라미터를 전달합니다.
        communityService.softDeletePost(postId, currentAdminId, reason);
        
        return "redirect:/admin/adminDetail";
    }
    
    /**
     * 댓글을 소프트 삭제합니다.
     */
    @PostMapping("/delete-comment")
    public String deleteComment(@RequestParam("commentId") Long commentId) {
        // TODO 1: 현재 로그인한 관리자의 ID를 가져와야 합니다.
        Long currentAdminId = 1L; // 임시로 관리자 ID를 1로 가정합니다.

        // TODO 2: 삭제 사유를 파라미터로 받거나 기본값을 지정합니다.
        String reason = "관리자에 의한 댓글 숨김 처리";

        // 올바른 파라미터 개수에 맞춰 메소드를 호출합니다.
        communityService.softDeleteComment(commentId, currentAdminId, reason);
        
        return "redirect:/admin/adminDetail";
    }
    
    
 // ----------------- 추가될 로직 -----------------
    // 게시글 영구 삭제
    @PostMapping("/hard-delete-post")
    public String hardDeletePost(@RequestParam("postId") Long postId) {
        communityService.hardDeletePostById(postId);
        return "redirect:/admin/adminDetail";
    }
    
    // 댓글 영구 삭제
    @PostMapping("/hard-delete-comment")
    public String hardDeleteComment(@RequestParam("commentId") Long commentId) {
        communityService.hardDeleteCommentById(commentId);
        return "redirect:/admin/adminDetail";
    }
    // ---------------------------------------------
    
    
    
    
    
    
    
}

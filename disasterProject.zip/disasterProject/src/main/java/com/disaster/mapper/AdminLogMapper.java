package com.disaster.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.disaster.domain.AdminLogDTO;

@Mapper
public interface AdminLogMapper {
	
	void insertLog(AdminLogDTO log);
	
	List<AdminLogDTO> findAllLogs();
}

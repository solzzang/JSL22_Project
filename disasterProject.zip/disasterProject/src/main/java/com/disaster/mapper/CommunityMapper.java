package com.disaster.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.disaster.domain.CommentDTO;
import com.disaster.domain.CommunityDTO;

@Mapper
public interface CommunityMapper {
	
	//전체 게시글 수
	int getTotalPostCount();
	
	//전체 댓글 수
	int getTotalCommentCount();
	
	//게시글 조회 (신고된 게시글 우선)
	List<CommunityDTO> findAllPostsWithReportedFirst();
	
	//신고된 댓글만 조회
	List<CommentDTO> findReportedComments();
	
	//게시글 삭제
	void softDeletePostById(Long postId);
	
	//댓글 삭제
	void softDeleteCommentById(Long commentId);
	
	// 소프트 삭제된 게시물 조회
	List<CommunityDTO> findSoftDeletedPosts();
	
	// 소프트 삭제된 댓글 조회
    List<CommentDTO> findSoftDeletedComments(); 
    
    // 게시물 영구 삭제
    void hardDeletePostById(Long postId); 
    
    // 댓글 영구 삭제
    void hardDeleteCommentById(Long commentId); 
	
}

package com.disaster.service;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.disaster.domain.AdminLogDTO;
import com.disaster.domain.CommentDTO;
import com.disaster.domain.CommunityDTO;
import com.disaster.mapper.CommunityMapper;
import lombok.RequiredArgsConstructor;

/**
 * CommunityService 인터페이스의 구현 클래스입니다.
 */
@Service
@RequiredArgsConstructor
public class CommunityService {

    private final CommunityMapper communityMapper;
    private final AdminLogService adminLogService;

     
    @Transactional(readOnly = true)
    public int getTotalPostCount() {
        return communityMapper.getTotalPostCount();
    }

     
    @Transactional(readOnly = true)
    public int getTotalCommentCount() {
        return communityMapper.getTotalCommentCount();
    }

     
    @Transactional(readOnly = true)
    public List<CommunityDTO> findAllPostsWithReportedFirst() {
        return communityMapper.findAllPostsWithReportedFirst();
    }

     
    @Transactional(readOnly = true)
    public List<CommentDTO> findReportedComments() {
        return communityMapper.findReportedComments();
    }

     
    @Transactional
    public void softDeletePost(Long postId, Long adminId, String reason) {
        communityMapper.softDeletePostById(postId);

        AdminLogDTO log = new AdminLogDTO();
        log.setAdminMemberId(adminId); // 컨트롤러에서 전달받은 관리자 ID 사용
        log.setTargetPostId(postId);
        log.setAction("HIDE_POST");
        log.setNote(reason);
        adminLogService.recordLog(log);
    }

     
    @Transactional
    public void softDeleteComment(Long commentId, Long adminId, String reason) {
        communityMapper.softDeleteCommentById(commentId);

        AdminLogDTO log = new AdminLogDTO();
        log.setAdminMemberId(adminId);
        log.setTargetCommentId(commentId);
        log.setAction("HIDE_COMMENT");
        log.setNote(reason);
        adminLogService.recordLog(log);
    }

     
    @Transactional(readOnly = true)
    public List<CommunityDTO> findSoftDeletedPosts() {
        return communityMapper.findSoftDeletedPosts();
    }

     
    @Transactional(readOnly = true)
    public List<CommentDTO> findSoftDeletedComments() {
        return communityMapper.findSoftDeletedComments();
    }

     
    @Transactional
    public void hardDeletePostById(Long postId) {
        // TODO: 이 게시글을 참조하는 댓글, 신고 기록 등을 먼저 삭제하는 로직이 필요합니다.
        communityMapper.hardDeletePostById(postId);
    }

     
    @Transactional
    public void hardDeleteCommentById(Long commentId) {
        // TODO: 이 댓글을 참조하는 신고 기록 등을 먼저 삭제하는 로직이 필요합니다.
        communityMapper.hardDeleteCommentById(commentId);
    }
}
